import torch
  
def load_checkpoint(ckpt_path):
    try:
        ckpt = torch.load(ckpt_path, map_location="cpu", weights_only=False)  # Set weights_only to False
        return ckpt
    except Exception as e:
        print(f"Error loading checkpoint: {e}")
        return None

# Example usage
ckpt_path = "/home/pavana/Video-LLaMA/Video-LLaMA-2-7B-Pretrained/VL_LLaMA_2_7B_Pretrained.pth"
ckpt = load_checkpoint(ckpt_path)
if ckpt is not None:
    print("Checkpoint loaded successfully.")
else:
    print("Failed to load checkpoint.")
